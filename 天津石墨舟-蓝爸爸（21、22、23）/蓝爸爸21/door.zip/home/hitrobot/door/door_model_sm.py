#!/usr/bin/env python
# -*- coding: utf-8 -*-
###########################################################
#               WARNING: Generated code!                  #
#              **************************                 #
# Manual changes may get lost if file is generated again. #
# Only code inside the [MANUAL] tags will be kept.        #
###########################################################

from flexbe_core import Behavior, Autonomy, OperatableStateMachine, ConcurrencyContainer, PriorityContainer, Logger
from agv_flexbe_behaviors.lift_dump_sm import lift_dumpSM
from agv_flexbe_states.door_call import door_call
from agv_flexbe_states.homing_control import HomingControl
from agv_flexbe_states.site_navigation import SiteNavigation
from agv_flexbe_states.wait_time import WaitTime
# Additional imports can be added inside the following tags
# [MANUAL_IMPORT]

# [/MANUAL_IMPORT]


'''
Created on @author: hus
@author: hus
'''
class door_modelSM(Behavior):
	'''
	door_model
	'''


	def __init__(self):
		super(door_modelSM, self).__init__()
		self.name = 'door_model'

		# parameters of this behavior

		# references to used behaviors
		self.add_behavior(lift_dumpSM, 'lift_dump')

		# Additional initialization code can be added inside the following tags
		# [MANUAL_INIT]
		
		# [/MANUAL_INIT]

		# Behavior comments:



	def create(self):
		# x:947 y:152, x:1333 y:90, x:333 y:90
		_state_machine = OperatableStateMachine(outcomes=['true', 'failed', 'false'], input_keys=['from_site', 'to_site'])
		_state_machine.userdata.from_site = "2F_from"
		_state_machine.userdata.to_site = "2F_to"

		# Additional creation code can be added inside the following tags
		# [MANUAL_CREATE]
		
		# [/MANUAL_CREATE]


		with _state_machine:
			# x:98 y:91
			OperatableStateMachine.add('3F_Door_forward',
										SiteNavigation(site_name="3F_Door_forward"),
										transitions={'arrived': 'door_out_open', 'canceled': '3F_Door_forward', 'failed': '3F_Door_forward'},
										autonomy={'arrived': Autonomy.Off, 'canceled': Autonomy.Off, 'failed': Autonomy.Off})

			# x:764 y:299
			OperatableStateMachine.add('do_backward_2.2',
										HomingControl(target_frame="base_link", target_x=-2.2, target_y=0, target_yaw=0),
										transitions={'succeeded': 'door_out_close', 'failed': 'do_backward_2.2'},
										autonomy={'succeeded': Autonomy.Off, 'failed': Autonomy.Off})

			# x:698 y:167
			OperatableStateMachine.add('door_out_close',
										door_call(topic="dadong_door", name="door_call", mb_addr="2", mb_data="0", timeoff=2.0, timeout=0.0),
										transitions={'done': 'true', 'failed': 'door_out_close'},
										autonomy={'done': Autonomy.Off, 'failed': Autonomy.Off},
										remapping={'to_site': 'to_site'})

			# x:259 y:191
			OperatableStateMachine.add('door_out_open',
										door_call(topic="dadong_door", name="door_call", mb_addr="1", mb_data="0", timeoff=2.0, timeout=0.0),
										transitions={'done': 'wait_10s', 'failed': 'false'},
										autonomy={'done': Autonomy.Off, 'failed': Autonomy.Off},
										remapping={'to_site': 'to_site'})

			# x:445 y:166
			OperatableStateMachine.add('lift_dump',
										self.use_behavior(lift_dumpSM, 'lift_dump'),
										transitions={'finished': 'do_backward_2.2'},
										autonomy={'finished': Autonomy.Inherit})

			# x:297 y:344
			OperatableStateMachine.add('wait_10s',
										WaitTime(wait_time=10),
										transitions={'done': '3F_Door'},
										autonomy={'done': Autonomy.Off})

			# x:507 y:419
			OperatableStateMachine.add('3F_Door',
										SiteNavigation(site_name="3F_Door"),
										transitions={'arrived': 'lift_dump', 'canceled': '3F_Door', 'failed': '3F_Door'},
										autonomy={'arrived': Autonomy.Off, 'canceled': Autonomy.Off, 'failed': Autonomy.Off})


		return _state_machine


	# Private functions can be added inside the following tags
	# [MANUAL_FUNC]
	
	# [/MANUAL_FUNC]
