#!/usr/bin/env python

from flexbe_core import EventState, Logger
from flexbe_core.proxy import ProxyPublisher
from flexbe_core.proxy import ProxySubscriberCached
from diagnostic_msgs.msg import DiagnosticArray
from std_msgs.msg import Header, String
import rospy

class door_call(EventState):
    '''
    Publish String & Subscribe DiagnosticArray topic

    -- topic        	stirng	topic name
    -- name             string	event name, trigger driver's event list
    -- mb_addr          int/double  mb address
    -- mb_data          int/double 	mb data
    -- timeoff          double  time to repeat writing
    -- timeout          double  time to reading failed

    <= done             publishing done
    <= failed           publishing failed

    '''

    def __init__(self, topic, name, mb_addr, mb_data, timeoff=1.0, timeout=0.0):
        super(door_call, self).__init__(outcomes=['done', 'failed'], input_keys=['to_site'])
        self._update_pub = ProxyPublisher({'flexbe/behavior_updating': String})

        self._mb_addr = mb_addr
        self._mb_data = mb_data
        self._name = name
        self._timeoff = timeoff
        self._timeout = timeout
        self._topic = topic
        self._pub = ProxyPublisher({self._topic: String})
        self._sub = ProxySubscriberCached({self._name: DiagnosticArray})
        if mb_data == "0":
            self.floor_name = "OUT"
        elif mb_data == "1":
            self.floor_name = "IN"

    def execute(self, userdata):
        self._time_execute = rospy.Time.now()
        if self._timeout > 0.0:
            if (self._time_execute - self._time_enter) >= rospy.Duration(self._timeout):
                return 'failed'

        if self._timeoff > 0.0:
            if (self._time_execute - self._time_publish) >= rospy.Duration(self._timeoff):
                msg = String()
                msg.data = '{ "name": "' + self.floor_name + '", ' + '"mb_addr": ' + str(self._mb_addr) + ', ' + '"mb_data": ' + str(self._mb_data) + ' }'
                self._pub.publish(self._topic, msg)
                self._time_publish = rospy.Time.now()

        if self._sub.has_msg(self._name):
            msg = self._sub.get_last_msg(self._name)
            self._sub.remove_last_msg(self._name)
            for i in range(len(msg.status)):
                if True: #self._hardware_id == "" or self._hardware_id == msg.status[i].hardware_id:
                    for j in range(len(msg.status[i].values)):
                        if True: #self._key == msg.status[i].values[j].key:
                            if msg.status[i].values[j].value == self._mb_data:
                                return 'done'
                            elif self._mb_data[0:1] == "=":
                                if float(msg.status[i].values[j].value) == float(self._mb_data[1:]):
                                    return 'done'
                            elif self._mb_data[0:2] == "~=":
                                factor = 10**len(self._mb_data.split('.')[1])
                                if round(float(msg.status[i].values[j].value) * factor) == round(float(self._mb_data[2:]) * factor):
                                    return 'done'
                            elif self._mb_data[0:2] == "!=":
                                if float(msg.status[i].values[j].value) != float(self._mb_data[2:]):
                                    return 'done'
                            elif self._mb_data[0:2] == ">=" or self._mb_data[0:2] == "=>":
                                if float(msg.status[i].values[j].value) >= float(self._mb_data[2:]):
                                    return 'done'
                            elif self._mb_data[0:2] == "<=" or self._mb_data[0:2] == "=<":
                                if float(msg.status[i].values[j].value) <= float(self._mb_data[2:]):
                                    return 'done'
                            elif self._mb_data[0:1] == ">":
                                if float(msg.status[i].values[j].value) > float(self._mb_data[2:]):
                                    return 'done'
                            elif self._mb_data[0:1] == "<":
                                if float(msg.status[i].values[j].value) < float(self._mb_data[2:]):
                                    return 'done'

    def on_enter(self, userdata):
        to_site = userdata.to_site
        split_index = to_site.find('F')
        floor = to_site[:split_index]
        if floor == "1":
            self._mb_data = 0
        elif floor == "1B":
            self._mb_data = 0
        elif floor == "2":
            self._mb_data = str(int(self._mb_data) + 52)
        elif floor == "2B":
            self._mb_data = 0
        elif floor == "3":
            self._mb_data = str(int(self._mb_data) + 54)
        elif floor == "4":
            self._mb_data = str(int(self._mb_data) + 56)
        self.floor_name = self._name + "_L" + floor + self.floor_name

        update_msg = String()
        update_msg.data = self.name
        self._update_pub.publish('flexbe/behavior_updating', update_msg)

        msg = String()
        msg.data = '{ "name": "' + self.floor_name + '", ' + '"mb_addr": ' + str(self._mb_addr) + ', ' + '"mb_data": ' + str(self._mb_data) + ' }'
        self._pub.publish(self._topic, msg)
        self._time_publish = rospy.Time.now()

        self._sub.enable_buffer(self._name)
        self._time_enter = rospy.Time.now()

    def on_exit(self, userdata):
        self._sub.disable_buffer(self._name)
